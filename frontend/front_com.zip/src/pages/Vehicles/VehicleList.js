import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { vehicleAPI } from '../../services/api';
import Table from '../../components/common/Table';
import Button from '../../components/common/Button';
import SearchBar from '../../components/common/SearchBar';

const VehicleList = () => {
  const navigate = useNavigate();
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchVehicles();
  }, []);

  const fetchVehicles = async () => {
    try {
      setLoading(true);
      const response = await vehicleAPI.getAll();
      setVehicles(response.data.data || []);
    } catch (error) {
      console.error('Error:', error);
      alert('Không thể tải danh sách phương tiện');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (maXe) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa phương tiện này?')) return;

    try {
      await vehicleAPI.delete(maXe);
      alert('✅ Xóa phương tiện thành công!');
      fetchVehicles();
    } catch (error) {
      alert('❌ Không thể xóa phương tiện');
    }
  };

  const filteredVehicles = vehicles.filter(v =>
    v.BienSo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.HangXe?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.LoaiXe?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const columns = [
    {
      key: 'MaXe',
      label: 'Mã xe',
      render: (row) => <span className="font-medium text-blue-600">{row.MaXe}</span>
    },
    {
      key: 'BienSo',
      label: 'Biển số',
      render: (row) => <span className="font-bold text-green-700">{row.BienSo}</span>
    },
    { key: 'HangXe', label: 'Hãng xe' },
    { key: 'LoaiXe', label: 'Loại xe' },
    { key: 'NamSX', label: 'Năm SX' },
    {
      key: 'GiaTriXe',
      label: 'Giá trị',
      render: (row) => new Intl.NumberFormat('vi-VN').format(row.GiaTriXe) + ' đ'
    },
    { key: 'TinhTrangKT', label: 'Tình trạng' },
    {
      key: 'actions',
      label: 'Thao tác',
      render: (row) => (
        <div className="flex space-x-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/vehicles/${row.MaXe}`);
            }}
            className="text-blue-600 hover:underline"
          >
            Xem
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/vehicles/edit/${row.MaXe}`);
            }}
            className="text-green-600 hover:underline"
          >
            Sửa
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleDelete(row.MaXe);
            }}
            className="text-red-600 hover:underline"
          >
            Xóa
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Quản lý Phương tiện</h1>
        <p className="text-gray-600 mt-2">Danh sách tất cả phương tiện trong hệ thống</p>
      </div>

      <SearchBar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        placeholder="Tìm kiếm theo biển số, hãng xe, loại xe..."
        actions={[
          {
            label: 'Thêm phương tiện',
            variant: 'primary',
            onClick: () => navigate('/vehicles/new'),
            icon: <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          }
        ]}
      />

      {/* Stats */}
      <div className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Tổng phương tiện</div>
          <div className="text-2xl font-bold text-gray-900">{vehicles.length}</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Tình trạng tốt</div>
          <div className="text-2xl font-bold text-green-600">
            {vehicles.filter(v => v.TinhTrangKT === 'Tốt').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Cần bảo dưỡng</div>
          <div className="text-2xl font-bold text-yellow-600">
            {vehicles.filter(v => v.TinhTrangKT !== 'Tốt' && v.TinhTrangKT !== 'Yếu').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Tổng giá trị</div>
          <div className="text-2xl font-bold text-blue-600">
            {new Intl.NumberFormat('vi-VN', { notation: 'compact' }).format(
              vehicles.reduce((sum, v) => sum + (v.GiaTriXe || 0), 0)
            )} đ
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow">
        <Table
          columns={columns}
          data={filteredVehicles}
          loading={loading}
          onRowClick={(row) => navigate(`/vehicles/${row.MaXe}`)}
          emptyMessage="Chưa có phương tiện nào"
        />
      </div>
    </div>
  );
};

export default VehicleList;
