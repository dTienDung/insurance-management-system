import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { vehicleService } from '../../services/vehicleService';
import { customerService } from '../../services/customerService';

const VehicleForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const customerIdFromQuery = searchParams.get('customer_id');
  
  const [formData, setFormData] = useState({
    customer_id: customerIdFromQuery || '',
    license_plate: '',
    vehicle_type: 'car',
    manufacturer: '',
    model: '',
    manufacturing_year: new Date().getFullYear(),
    engine_number: '',
    chassis_number: '',
    color: '',
    notes: ''
  });

  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loadingCustomers, setLoadingCustomers] = useState(true);

  const isEditMode = !!id;

  // Danh sách các loại xe phổ biến
  const vehicleTypes = [
    { value: 'car', label: 'Ô tô' },
    { value: 'motorcycle', label: 'Xe máy' },
    { value: 'truck', label: 'Xe tải' },
    { value: 'bus', label: 'Xe khách' },
    { value: 'van', label: 'Xe van' },
    { value: 'suv', label: 'SUV' },
    { value: 'pickup', label: 'Bán tải' }
  ];

  // Danh sách hãng xe phổ biến
  const manufacturers = [
    'Toyota', 'Honda', 'Mazda', 'Ford', 'Hyundai', 
    'Kia', 'Mercedes-Benz', 'BMW', 'Audi', 'Volkswagen',
    'Nissan', 'Mitsubishi', 'Suzuki', 'Chevrolet', 'Lexus',
    'Vinfast', 'Thaco', 'Yamaha', 'Piaggio', 'SYM'
  ].sort();

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 50 }, (_, i) => currentYear - i);

  useEffect(() => {
    fetchCustomers();
    if (id) {
      fetchVehicle();
    }
  }, [id]);

  useEffect(() => {
    if (formData.customer_id) {
      const customer = customers.find(c => c.customer_id === parseInt(formData.customer_id));
      setSelectedCustomer(customer);
    }
  }, [formData.customer_id, customers]);

  const fetchCustomers = async () => {
    try {
      setLoadingCustomers(true);
      const data = await customerService.getAll();
      setCustomers(data);
    } catch (err) {
      console.error('Error fetching customers:', err);
      setError('Lỗi khi tải danh sách khách hàng');
    } finally {
      setLoadingCustomers(false);
    }
  };

  const fetchVehicle = async () => {
    try {
      setLoading(true);
      const data = await vehicleService.getById(id);
      setFormData({
        customer_id: data.vehicle.customer_id,
        license_plate: data.vehicle.license_plate,
        vehicle_type: data.vehicle.vehicle_type || 'car',
        manufacturer: data.vehicle.manufacturer,
        model: data.vehicle.model,
        manufacturing_year: data.vehicle.manufacturing_year,
        engine_number: data.vehicle.engine_number,
        chassis_number: data.vehicle.chassis_number,
        color: data.vehicle.color || '',
        notes: data.vehicle.notes || ''
      });
    } catch (err) {
      setError('Lỗi khi tải thông tin phương tiện');
      console.error('Error fetching vehicle:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateLicensePlate = (plate) => {
    // Định dạng biển số Việt Nam: 29A-12345 hoặc 29A12345
    const regex = /^[0-9]{2}[A-Z]{1,2}[0-9]{4,5}$/;
    const formattedPlate = plate.replace(/[-\s]/g, '').toUpperCase();
    return regex.test(formattedPlate);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.customer_id) {
      setError('Vui lòng chọn khách hàng');
      return;
    }
    
    if (!formData.license_plate.trim()) {
      setError('Vui lòng nhập biển số xe');
      return;
    }

    // Format biển số (loại bỏ dấu gạch ngang và khoảng trắng, viết hoa)
    const formattedPlate = formData.license_plate.replace(/[-\s]/g, '').toUpperCase();
    
    if (!validateLicensePlate(formattedPlate)) {
      setError('Biển số xe không đúng định dạng. Ví dụ: 29A12345 hoặc 29A-12345');
      return;
    }

    if (!formData.manufacturer.trim()) {
      setError('Vui lòng chọn hoặc nhập hãng xe');
      return;
    }

    if (!formData.model.trim()) {
      setError('Vui lòng nhập model xe');
      return;
    }

    if (!formData.engine_number.trim()) {
      setError('Vui lòng nhập số máy');
      return;
    }

    if (!formData.chassis_number.trim()) {
      setError('Vui lòng nhập số khung');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const dataToSubmit = {
        ...formData,
        license_plate: formattedPlate,
        manufacturing_year: parseInt(formData.manufacturing_year)
      };

      if (isEditMode) {
        await vehicleService.update(id, dataToSubmit);
        alert('Cập nhật phương tiện thành công');
      } else {
        await vehicleService.create(dataToSubmit);
        alert('Thêm phương tiện mới thành công');
      }
      
      navigate('/vehicles');
    } catch (err) {
      setError(err.message || 'Có lỗi xảy ra khi lưu phương tiện');
      console.error('Error saving vehicle:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loadingCustomers || (isEditMode && loading)) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">
          {isEditMode ? 'Chỉnh sửa phương tiện' : 'Thêm phương tiện mới'}
        </h1>
        <p className="text-gray-600 mt-2">
          {isEditMode ? 'Cập nhật thông tin phương tiện' : 'Nhập thông tin phương tiện mới'}
        </p>
      </div>

      {error && (
        <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-6 space-y-6">
        {/* Customer Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Khách hàng <span className="text-red-500">*</span>
          </label>
          <select
            name="customer_id"
            value={formData.customer_id}
            onChange={handleChange}
            disabled={isEditMode}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed"
          >
            <option value="">-- Chọn khách hàng --</option>
            {customers.map(customer => (
              <option key={customer.customer_id} value={customer.customer_id}>
                {customer.full_name} - {customer.phone}
              </option>
            ))}
          </select>
          {selectedCustomer && (
            <div className="mt-2 p-3 bg-blue-50 rounded-lg text-sm">
              <p className="text-gray-700">
                <span className="font-medium">CCCD/CMND:</span> {selectedCustomer.id_number}
              </p>
              <p className="text-gray-700">
                <span className="font-medium">Địa chỉ:</span> {selectedCustomer.address}
              </p>
            </div>
          )}
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Thông tin xe</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* License Plate */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Biển số xe <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="license_plate"
                value={formData.license_plate}
                onChange={handleChange}
                required
                placeholder="Ví dụ: 29A-12345"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 uppercase"
              />
              <p className="mt-1 text-xs text-gray-500">
                Định dạng: 29A-12345 hoặc 29A12345
              </p>
            </div>

            {/* Vehicle Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Loại xe <span className="text-red-500">*</span>
              </label>
              <select
                name="vehicle_type"
                value={formData.vehicle_type}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                {vehicleTypes.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Manufacturer */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Hãng xe <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="manufacturer"
                value={formData.manufacturer}
                onChange={handleChange}
                required
                list="manufacturers-list"
                placeholder="Chọn hoặc nhập hãng xe"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <datalist id="manufacturers-list">
                {manufacturers.map(manufacturer => (
                  <option key={manufacturer} value={manufacturer} />
                ))}
              </datalist>
            </div>

            {/* Model */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Model <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="model"
                value={formData.model}
                onChange={handleChange}
                required
                placeholder="Ví dụ: Civic, Corolla"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Manufacturing Year */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Năm sản xuất <span className="text-red-500">*</span>
              </label>
              <select
                name="manufacturing_year"
                value={formData.manufacturing_year}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                {years.map(year => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>

            {/* Color */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Màu sắc
              </label>
              <input
                type="text"
                name="color"
                value={formData.color}
                onChange={handleChange}
                placeholder="Ví dụ: Trắng, Đen"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Thông tin kỹ thuật</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Engine Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Số máy <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="engine_number"
                value={formData.engine_number}
                onChange={handleChange}
                required
                placeholder="Nhập số máy"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 uppercase"
              />
            </div>

            {/* Chassis Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Số khung <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="chassis_number"
                value={formData.chassis_number}
                onChange={handleChange}
                required
                placeholder="Nhập số khung"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 uppercase"
              />
            </div>
          </div>
        </div>

        {/* Notes */}
        <div className="border-t pt-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ghi chú
          </label>
          <textarea
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows="4"
            placeholder="Nhập các ghi chú về phương tiện (tình trạng, lịch sử bảo dưỡng, v.v.)"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-6 border-t">
          <button
            type="button"
            onClick={() => navigate('/vehicles')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Hủy
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {loading && (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            )}
            {isEditMode ? 'Cập nhật' : 'Thêm mới'}
          </button>
        </div>
      </form>

      {/* Help Section */}
      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">💡 Gợi ý:</h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Biển số xe phải đúng định dạng Việt Nam (VD: 29A-12345)</li>
          <li>• Số máy và số khung phải chính xác theo đăng ký xe</li>
          <li>• Kiểm tra kỹ thông tin trước khi lưu để tránh sai sót</li>
        </ul>
      </div>
    </div>
  );
};

export default VehicleForm;
