import { contractAPI } from './api';

export const contractService = {
  // Lấy danh sách tất cả hợp đồng
  getAll: async (params = {}) => {
    try {
      const response = await contractAPI.getAll(params);
      return response.data;
    } catch (error) {
      console.error('Error fetching contracts:', error);
      throw error;
    }
  },

  // Lấy thông tin chi tiết hợp đồng theo ID
  getById: async (id) => {
    try {
      const response = await contractAPI.getById(id);
      return response.data;
    } catch (error) {
      console.error(`Error fetching contract ${id}:`, error);
      throw error;
    }
  },

  // Lấy danh sách hợp đồng sắp hết hạn
  getExpiring: async (params = {}) => {
    try {
      const response = await contractAPI.getExpiring(params);
      return response.data;
    } catch (error) {
      console.error('Error fetching expiring contracts:', error);
      throw error;
    }
  },

  // Tạo hợp đồng mới
  create: async (contractData) => {
    try {
      const response = await contractAPI.create(contractData);
      return response.data;
    } catch (error) {
      console.error('Error creating contract:', error);
      throw error;
    }
  },

  // Cập nhật thông tin hợp đồng
  update: async (id, contractData) => {
    try {
      const response = await contractAPI.update(id, contractData);
      return response.data;
    } catch (error) {
      console.error(`Error updating contract ${id}:`, error);
      throw error;
    }
  },

  // Xóa hợp đồng
  delete: async (id) => {
    try {
      const response = await contractAPI.delete(id);
      return response.data;
    } catch (error) {
      console.error(`Error deleting contract ${id}:`, error);
      throw error;
    }
  },

  // Hủy hợp đồng
  cancel: async (id, reason) => {
    try {
      const response = await contractAPI.cancel(id, { reason });
      return response.data;
    } catch (error) {
      console.error(`Error cancelling contract ${id}:`, error);
      throw error;
    }
  },

  // Tái tục hợp đồng
  renew: async (id, renewData) => {
    try {
      const response = await contractAPI.renew(id, renewData);
      return response.data;
    } catch (error) {
      console.error(`Error renewing contract ${id}:`, error);
      throw error;
    }
  },

  // ============================================
  // PAYMENT METHODS - MỚI THÊM
  // ============================================

  /**
   * Cập nhật trạng thái thanh toán của hợp đồng
   * @param {number} id - ID của hợp đồng
   * @param {Object} paymentData - Dữ liệu thanh toán
   * @param {string} paymentData.payment_date - Ngày thanh toán (YYYY-MM-DD)
   * @param {string} paymentData.payment_method - Hình thức thanh toán (cash/transfer/card)
   * @param {string} paymentData.payment_notes - Ghi chú thanh toán (optional)
   * @returns {Promise} Response data
   */
  updatePaymentStatus: async (id, paymentData) => {
    try {
      const response = await contractAPI.update(id, {
        payment_status: 'paid',
        payment_date: paymentData.payment_date,
        payment_method: paymentData.payment_method,
        payment_notes: paymentData.payment_notes || ''
      });
      return response.data;
    } catch (error) {
      console.error(`Error updating payment status for contract ${id}:`, error);
      throw error;
    }
  },

  /**
   * Lấy thông tin thanh toán của hợp đồng
   * @param {number} id - ID của hợp đồng
   * @returns {Promise} Payment info
   */
  getPaymentInfo: async (id) => {
    try {
      const response = await contractAPI.getById(id);
      const contract = response.data.contract;
      return {
        payment_status: contract.payment_status,
        payment_date: contract.payment_date,
        payment_method: contract.payment_method,
        payment_notes: contract.payment_notes,
        premium_amount: contract.premium_amount
      };
    } catch (error) {
      console.error(`Error fetching payment info for contract ${id}:`, error);
      throw error;
    }
  },

  /**
   * Đánh dấu hợp đồng chưa thanh toán (rollback)
   * @param {number} id - ID của hợp đồng
   * @returns {Promise} Response data
   */
  markAsUnpaid: async (id) => {
    try {
      const response = await contractAPI.update(id, {
        payment_status: 'unpaid',
        payment_date: null,
        payment_method: null,
        payment_notes: null
      });
      return response.data;
    } catch (error) {
      console.error(`Error marking contract ${id} as unpaid:`, error);
      throw error;
    }
  },

  /**
   * Lấy danh sách hợp đồng theo trạng thái thanh toán
   * @param {string} paymentStatus - 'paid' hoặc 'unpaid'
   * @returns {Promise} List of contracts
   */
  getByPaymentStatus: async (paymentStatus) => {
    try {
      const response = await contractAPI.getAll({ 
        payment_status: paymentStatus 
      });
      return response.data;
    } catch (error) {
      console.error(`Error fetching contracts by payment status:`, error);
      throw error;
    }
  },

  /**
   * Thống kê thanh toán
   * @param {Object} params - Query params
   * @returns {Promise} Payment statistics
   */
  getPaymentStatistics: async (params = {}) => {
    try {
      const response = await contractAPI.getAll(params);
      const contracts = response.data;
      
      const stats = {
        total: contracts.length,
        paid: contracts.filter(c => c.payment_status === 'paid').length,
        unpaid: contracts.filter(c => c.payment_status === 'unpaid').length,
        totalAmount: contracts.reduce((sum, c) => sum + parseFloat(c.premium_amount), 0),
        paidAmount: contracts
          .filter(c => c.payment_status === 'paid')
          .reduce((sum, c) => sum + parseFloat(c.premium_amount), 0),
        unpaidAmount: contracts
          .filter(c => c.payment_status === 'unpaid')
          .reduce((sum, c) => sum + parseFloat(c.premium_amount), 0)
      };
      
      return stats;
    } catch (error) {
      console.error('Error fetching payment statistics:', error);
      throw error;
    }
  }
};

export default contractService;