import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Table from '../../components/common/Table';
import Button from '../../components/common/Button';
import contractService from '../../services/contractService';
import exportService from '../../services/exportService';
import { format } from 'date-fns';

const ContractList = () => {
  const navigate = useNavigate();
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // all, active, expired, pending

  useEffect(() => {
    fetchContracts();
  }, [filter]);

  const fetchContracts = async () => {
    try {
      setLoading(true);
      const response = await contractService.getAll({ status: filter !== 'all' ? filter : undefined });
      setContracts(response.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (maHD) => {
    try {
      await exportService.exportHopDong(maHD);
      alert('Xuất hợp đồng thành công!');
    } catch (error) {
      alert('Không thể xuất hợp đồng');
    }
  };

  const handleRenew = async (maHD) => {
    if (!window.confirm('Bạn có muốn tái tục hợp đồng này?')) return;
    
    try {
      await contractService.renew(maHD, {});
      alert('Tái tục hợp đồng thành công!');
      fetchContracts();
    } catch (error) {
      alert('Không thể tái tục hợp đồng');
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      'Hiệu lực': 'bg-green-100 text-green-800',
      'Hết hạn': 'bg-gray-100 text-gray-800',
      'Chờ duyệt': 'bg-yellow-100 text-yellow-800',
      'Đã hủy': 'bg-red-100 text-red-800'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${badges[status] || 'bg-gray-100'}`}>
        {status}
      </span>
    );
  };

  const columns = [
    { key: 'MaHD', label: 'Mã HĐ' },
    { key: 'KhachHang', label: 'Khách hàng' },
    { key: 'BienSo', label: 'Biển số' },
    { 
      key: 'PhiBaoHiem', 
      label: 'Phí BH',
      render: (row) => new Intl.NumberFormat('vi-VN').format(row.PhiBaoHiem) + ' đ'
    },
    {
      key: 'NgayKy',
      label: 'Ngày ký',
      render: (row) => format(new Date(row.NgayKy), 'dd/MM/yyyy')
    },
    {
      key: 'NgayHetHan',
      label: 'Hết hạn',
      render: (row) => format(new Date(row.NgayHetHan), 'dd/MM/yyyy')
    },
    {
      key: 'TrangThai',
      label: 'Trạng thái',
      render: (row) => getStatusBadge(row.TrangThai)
    },
    {
      key: 'actions',
      label: 'Thao tác',
      render: (row) => (
        <div className="flex flex-col space-y-1">
          <button onClick={() => handleExport(row.MaHD)} className="text-blue-600 hover:underline text-sm">
            📄 Xuất HĐ
          </button>
          {row.TrangThai === 'Hết hạn' && (
            <button onClick={() => handleRenew(row.MaHD)} className="text-green-600 hover:underline text-sm">
              🔄 Tái tục
            </button>
          )}
        </div>
      )
    }
  ];

  return (
    <div className="p-6">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Quản lý Hợp đồng</h1>
          <p className="text-gray-600 mt-1">Danh sách hợp đồng bảo hiểm</p>
        </div>
        <Button onClick={() => navigate('/contracts/new')}>+ Tạo hợp đồng</Button>
      </div>

      {/* Filters */}
      <div className="mb-6 flex space-x-2">
        {['all', 'active', 'expired', 'pending'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg ${filter === f ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
          >
            {f === 'all' ? 'Tất cả' : f === 'active' ? 'Hiệu lực' : f === 'expired' ? 'Hết hạn' : 'Chờ duyệt'}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-lg shadow">
        <Table columns={columns} data={contracts} loading={loading} />
      </div>
    </div>
  );
};

export default ContractList;
