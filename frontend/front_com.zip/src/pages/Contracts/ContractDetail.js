import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { contractService } from '../../services/contractService';
import { exportService } from '../../services/exportService';
import PaymentModal from '../../components/common/PaymentModal';
import { 
  DocumentTextIcon, 
  UserIcon, 
  TruckIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  ClipboardDocumentListIcon,
  CheckCircleIcon,
  XCircleIcon,
  PrinterIcon,
  BanknotesIcon
} from '@heroicons/react/24/outline';

const ContractDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [contract, setContract] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [vehicle, setVehicle] = useState(null);
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('info');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [processingPayment, setProcessingPayment] = useState(false);

  useEffect(() => {
    fetchContractDetails();
  }, [id]);

  const fetchContractDetails = async () => {
    try {
      setLoading(true);
      const data = await contractService.getById(id);
      setContract(data.contract);
      setCustomer(data.customer);
      setVehicle(data.vehicle);
      setAssessments(data.assessments || []);
      setError(null);
    } catch (err) {
      setError(err.message || 'Lỗi khi tải thông tin hợp đồng');
      console.error('Error fetching contract:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    navigate(`/contracts/edit/${id}`);
  };

  const handleDelete = async () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa hợp đồng này?')) {
      try {
        await contractService.delete(id);
        alert('Đã xóa hợp đồng thành công');
        navigate('/contracts');
      } catch (err) {
        alert('Lỗi khi xóa hợp đồng: ' + err.message);
      }
    }
  };

  // ============================================
  // PAYMENT FUNCTIONS - MỚI THÊM
  // ============================================
  const handleConfirmPayment = async (paymentData) => {
    try {
      setProcessingPayment(true);
      await contractService.updatePaymentStatus(id, paymentData);
      
      // Cập nhật lại contract state
      setContract(prev => ({
        ...prev,
        payment_status: 'paid',
        payment_date: paymentData.payment_date,
        payment_method: paymentData.payment_method,
        payment_notes: paymentData.payment_notes
      }));
      
      alert('✅ Đã cập nhật trạng thái thanh toán thành công!');
      setShowPaymentModal(false);
    } catch (err) {
      alert('Lỗi khi cập nhật thanh toán: ' + err.message);
    } finally {
      setProcessingPayment(false);
    }
  };

  const handlePrintReceipt = async () => {
    try {
      const blob = await exportService.exportBienLai(contract.payment_id || id);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `BienLai_${contract.contract_number}_${new Date().getTime()}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      alert('Lỗi khi xuất biên lai: ' + err.message);
    }
  };

  const handleExportContract = async () => {
    try {
      const blob = await exportService.exportHopDong(id);
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `HopDong_${contract.contract_number}_${new Date().getTime()}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      alert('Lỗi khi xuất hợp đồng: ' + err.message);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      active: { bg: 'bg-green-100', text: 'text-green-800', label: 'Còn hiệu lực' },
      expired: { bg: 'bg-red-100', text: 'text-red-800', label: 'Hết hạn' },
      cancelled: { bg: 'bg-gray-100', text: 'text-gray-800', label: 'Đã hủy' }
    };
    const badge = badges[status] || badges.cancelled;
    return (
      <span className={`px-3 py-1 text-sm font-medium rounded-full ${badge.bg} ${badge.text}`}>
        {badge.label}
      </span>
    );
  };

  const getPaymentStatusBadge = (status) => {
    if (status === 'paid') {
      return (
        <span className="px-3 py-1 text-sm font-medium rounded-full bg-green-100 text-green-800 flex items-center gap-2">
          <CheckCircleIcon className="w-4 h-4" />
          Đã thanh toán
        </span>
      );
    }
    return (
      <span className="px-3 py-1 text-sm font-medium rounded-full bg-yellow-100 text-yellow-800 flex items-center gap-2">
        <XCircleIcon className="w-4 h-4" />
        Chưa thanh toán
      </span>
    );
  };

  const getAssessmentStatusBadge = (status) => {
    const badges = {
      pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', label: 'Chờ xử lý' },
      approved: { bg: 'bg-green-100', text: 'text-green-800', label: 'Đã duyệt' },
      rejected: { bg: 'bg-red-100', text: 'text-red-800', label: 'Từ chối' }
    };
    const badge = badges[status] || badges.pending;
    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-full ${badge.bg} ${badge.text}`}>
        {badge.label}
      </span>
    );
  };

  const getPaymentMethodLabel = (method) => {
    const methods = {
      cash: 'Tiền mặt',
      transfer: 'Chuyển khoản',
      card: 'Thẻ ngân hàng'
    };
    return methods[method] || method;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Lỗi: {error}</p>
        <button onClick={() => navigate('/contracts')} className="mt-2 text-red-600 underline">
          Quay lại danh sách
        </button>
      </div>
    );
  }

  if (!contract) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <p className="text-yellow-600">Không tìm thấy thông tin hợp đồng</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Chi tiết hợp đồng</h1>
          <div className="flex items-center gap-3 mt-2">
            <p className="text-gray-600">Mã HĐ: {contract.contract_number}</p>
            {getStatusBadge(contract.status)}
            {getPaymentStatusBadge(contract.payment_status)}
          </div>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => navigate('/contracts')}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Quay lại
          </button>
          <button
            onClick={handleExportContract}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 flex items-center gap-2"
          >
            <PrinterIcon className="w-5 h-5" />
            In hợp đồng
          </button>
          <button
            onClick={handleEdit}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Chỉnh sửa
          </button>
          <button
            onClick={handleDelete}
            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Xóa
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex gap-8">
          <button
            onClick={() => setActiveTab('info')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'info'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Thông tin hợp đồng
          </button>
          <button
            onClick={() => setActiveTab('payment')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'payment'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Thanh toán
          </button>
          <button
            onClick={() => setActiveTab('parties')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'parties'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Bên liên quan
          </button>
          <button
            onClick={() => setActiveTab('assessments')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'assessments'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Định giá ({assessments.length})
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'info' && (
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Thông tin cơ bản</h3>
              
              <div className="flex items-start gap-3">
                <DocumentTextIcon className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Số hợp đồng</p>
                  <p className="font-medium text-gray-900 text-lg">{contract.contract_number}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <DocumentTextIcon className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Loại bảo hiểm</p>
                  <p className="font-medium text-gray-900">{contract.insurance_type}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CurrencyDollarIcon className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Phí bảo hiểm</p>
                  <p className="font-medium text-gray-900 text-lg text-green-600">
                    {parseFloat(contract.premium_amount).toLocaleString('vi-VN')} VNĐ
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CurrencyDollarIcon className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Số tiền bảo hiểm</p>
                  <p className="font-medium text-gray-900 text-lg text-blue-600">
                    {parseFloat(contract.coverage_amount).toLocaleString('vi-VN')} VNĐ
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Thời hạn</h3>
              
              <div className="flex items-start gap-3">
                <CalendarIcon className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Ngày bắt đầu</p>
                  <p className="font-medium text-gray-900">
                    {new Date(contract.start_date).toLocaleDateString('vi-VN')}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CalendarIcon className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Ngày kết thúc</p>
                  <p className="font-medium text-gray-900">
                    {new Date(contract.end_date).toLocaleDateString('vi-VN')}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                {contract.status === 'active' ? (
                  <CheckCircleIcon className="w-5 h-5 text-green-500 mt-0.5" />
                ) : (
                  <XCircleIcon className="w-5 h-5 text-red-500 mt-0.5" />
                )}
                <div>
                  <p className="text-sm text-gray-500">Trạng thái</p>
                  {getStatusBadge(contract.status)}
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CalendarIcon className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-500">Ngày ký</p>
                  <p className="font-medium text-gray-900">
                    {new Date(contract.created_at).toLocaleDateString('vi-VN')}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {contract.notes && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Ghi chú</h3>
              <p className="text-gray-700 whitespace-pre-wrap">{contract.notes}</p>
            </div>
          )}
        </div>
      )}

      {/* ============================================ */}
      {/* PAYMENT TAB - MỚI THÊM */}
      {/* ============================================ */}
      {activeTab === 'payment' && (
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Thông tin thanh toán</h3>
            {getPaymentStatusBadge(contract.payment_status)}
          </div>

          <div className="space-y-6">
            {/* Payment Summary */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Phí bảo hiểm</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {parseFloat(contract.premium_amount).toLocaleString('vi-VN')} VNĐ
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Trạng thái</p>
                  <p className="text-lg font-semibold">
                    {contract.payment_status === 'paid' ? (
                      <span className="text-green-600">✅ Đã thanh toán</span>
                    ) : (
                      <span className="text-yellow-600">⏳ Chưa thanh toán</span>
                    )}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Hình thức</p>
                  <p className="text-lg font-semibold text-gray-900">
                    {contract.payment_method ? getPaymentMethodLabel(contract.payment_method) : '-'}
                  </p>
                </div>
              </div>
            </div>

            {/* Payment Details */}
            {contract.payment_status === 'paid' && (
              <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                <h4 className="font-medium text-gray-900">Chi tiết thanh toán</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Ngày thanh toán</p>
                    <p className="font-medium text-gray-900">
                      {contract.payment_date 
                        ? new Date(contract.payment_date).toLocaleDateString('vi-VN')
                        : '-'
                      }
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Hình thức thanh toán</p>
                    <p className="font-medium text-gray-900">
                      {contract.payment_method ? getPaymentMethodLabel(contract.payment_method) : '-'}
                    </p>
                  </div>
                </div>

                {contract.payment_notes && (
                  <div>
                    <p className="text-sm text-gray-500">Ghi chú</p>
                    <p className="font-medium text-gray-900">{contract.payment_notes}</p>
                  </div>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4 border-t">
              {contract.payment_status !== 'paid' ? (
                <button
                  onClick={() => setShowPaymentModal(true)}
                  disabled={contract.status !== 'active'}
                  className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  <BanknotesIcon className="w-5 h-5" />
                  Đánh dấu đã thanh toán
                </button>
              ) : (
                <button
                  onClick={handlePrintReceipt}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <PrinterIcon className="w-5 h-5" />
                  In biên lai
                </button>
              )}

              {contract.status !== 'active' && contract.payment_status !== 'paid' && (
                <p className="text-sm text-yellow-600 flex items-center">
                  ⚠️ Chỉ có thể thanh toán khi hợp đồng đang có hiệu lực
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Parties Tab */}
      {activeTab === 'parties' && (
        <div className="space-y-6">
          {/* Customer Info */}
          {customer && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-3">
                  <UserIcon className="w-6 h-6 text-blue-600" />
                  <h3 className="text-lg font-semibold text-gray-900">Khách hàng</h3>
                </div>
                <button
                  onClick={() => navigate(`/customers/${customer.customer_id}`)}
                  className="text-blue-600 hover:text-blue-800 text-sm"
                >
                  Xem chi tiết →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-gray-500">Họ và tên</p>
                  <p className="font-medium text-gray-900">{customer.full_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">CCCD/CMND</p>
                  <p className="font-medium text-gray-900">{customer.id_number}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Số điện thoại</p>
                  <p className="font-medium text-gray-900">{customer.phone}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium text-gray-900">{customer.email || 'Chưa cập nhật'}</p>
                </div>
                <div className="md:col-span-2">
                  <p className="text-sm text-gray-500">Địa chỉ</p>
                  <p className="font-medium text-gray-900">{customer.address}</p>
                </div>
              </div>
            </div>
          )}

          {/* Vehicle Info */}
          {vehicle && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-3">
                  <TruckIcon className="w-6 h-6 text-blue-600" />
                  <h3 className="text-lg font-semibold text-gray-900">Phương tiện</h3>
                </div>
                <button
                  onClick={() => navigate(`/vehicles/${vehicle.vehicle_id}`)}
                  className="text-blue-600 hover:text-blue-800 text-sm"
                >
                  Xem chi tiết →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-gray-500">Biển số xe</p>
                  <p className="font-medium text-gray-900 text-lg">{vehicle.license_plate}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Loại xe</p>
                  <p className="font-medium text-gray-900">{vehicle.vehicle_type}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Hãng xe</p>
                  <p className="font-medium text-gray-900">{vehicle.manufacturer}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Model</p>
                  <p className="font-medium text-gray-900">{vehicle.model}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Năm sản xuất</p>
                  <p className="font-medium text-gray-900">{vehicle.manufacturing_year}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Màu sắc</p>
                  <p className="font-medium text-gray-900">{vehicle.color || 'Chưa cập nhật'}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Assessments Tab */}
      {activeTab === 'assessments' && (
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          {assessments.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <ClipboardDocumentListIcon className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <p>Chưa có định giá nào cho hợp đồng này</p>
              <button
                onClick={() => navigate(`/assessments/new?contract_id=${id}`)}
                className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Tạo định giá
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ngày định giá</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Giá trị định giá</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Người định giá</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trạng thái</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {assessments.map((assessment) => (
                    <tr key={assessment.assessment_id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                        {new Date(assessment.assessment_date).toLocaleDateString('vi-VN')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                        {parseFloat(assessment.assessed_value).toLocaleString('vi-VN')} VNĐ
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-gray-700">
                        {assessment.assessor_name || 'N/A'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {getAssessmentStatusBadge(assessment.status)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <button
                          onClick={() => navigate(`/assessments/${assessment.assessment_id}`)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          Chi tiết
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        contract={contract}
        onConfirm={handleConfirmPayment}
      />
    </div>
  );
};

export default ContractDetail;