import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { assessmentAPI } from '../../services/api';
import Table from '../../components/common/Table';
import Button from '../../components/common/Button';
import { format } from 'date-fns';

const AssessmentList = () => {
  const navigate = useNavigate();
  const [assessments, setAssessments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchAssessments();
  }, []);

  const fetchAssessments = async () => {
    try {
      setLoading(true);
      const response = await assessmentAPI.getAll();
      setAssessments(response.data.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRiskBadge = (risk) => {
    const colors = {
      'Thấp': 'bg-green-100 text-green-800',
      'Trung bình': 'bg-yellow-100 text-yellow-800',
      'Cao': 'bg-orange-100 text-orange-800',
      'Rất cao': 'bg-red-100 text-red-800'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[risk] || 'bg-gray-100'}`}>
        {risk}
      </span>
    );
  };

  const getResultBadge = (result) => {
    const colors = {
      'Chấp nhận': 'bg-green-100 text-green-800',
      'Từ chối': 'bg-red-100 text-red-800',
      'Yêu cầu bổ sung': 'bg-yellow-100 text-yellow-800'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[result] || 'bg-gray-100'}`}>
        {result}
      </span>
    );
  };

  const filteredData = filter === 'all' 
    ? assessments 
    : assessments.filter(a => {
        if (filter === 'pending') return a.KetQua === 'Yêu cầu bổ sung';
        if (filter === 'approved') return a.KetQua === 'Chấp nhận';
        if (filter === 'rejected') return a.KetQua === 'Từ chối';
        return true;
      });

  const columns = [
    { key: 'MaTD', label: 'Mã thẩm định' },
    { key: 'MaHD', label: 'Hợp đồng' },
    {
      key: 'NgayThamDinh',
      label: 'Ngày thẩm định',
      render: (row) => format(new Date(row.NgayThamDinh), 'dd/MM/yyyy')
    },
    {
      key: 'MucDoRuiRo',
      label: 'Mức rủi ro',
      render: (row) => getRiskBadge(row.MucDoRuiRo)
    },
    {
      key: 'KetQua',
      label: 'Kết quả',
      render: (row) => getResultBadge(row.KetQua)
    },
    { 
      key: 'GhiChu', 
      label: 'Ghi chú',
      render: (row) => (
        <div className="max-w-xs truncate" title={row.GhiChu}>
          {row.GhiChu}
        </div>
      )
    },
    {
      key: 'actions',
      label: 'Thao tác',
      render: (row) => (
        <button
          onClick={() => navigate(`/assessments/${row.MaTD}`)}
          className="text-blue-600 hover:underline"
        >
          Xem chi tiết
        </button>
      )
    }
  ];

  return (
    <div className="p-6">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Quản lý Thẩm định</h1>
          <p className="text-gray-600 mt-2">Danh sách thẩm định hợp đồng bảo hiểm</p>
        </div>
        <Button onClick={() => navigate('/assessments/new')}>
          + Tạo thẩm định
        </Button>
      </div>

      {/* Filters */}
      <div className="mb-6 flex space-x-2">
        {[
          { key: 'all', label: 'Tất cả' },
          { key: 'pending', label: 'Chờ bổ sung' },
          { key: 'approved', label: 'Đã duyệt' },
          { key: 'rejected', label: 'Từ chối' }
        ].map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-4 py-2 rounded-lg ${
              filter === f.key 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Tổng thẩm định</div>
          <div className="text-2xl font-bold text-gray-900">{assessments.length}</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Chấp nhận</div>
          <div className="text-2xl font-bold text-green-600">
            {assessments.filter(a => a.KetQua === 'Chấp nhận').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Từ chối</div>
          <div className="text-2xl font-bold text-red-600">
            {assessments.filter(a => a.KetQua === 'Từ chối').length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Chờ bổ sung</div>
          <div className="text-2xl font-bold text-yellow-600">
            {assessments.filter(a => a.KetQua === 'Yêu cầu bổ sung').length}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow">
        <Table
          columns={columns}
          data={filteredData}
          loading={loading}
          emptyMessage="Chưa có thẩm định nào"
        />
      </div>
    </div>
  );
};

export default AssessmentList;
