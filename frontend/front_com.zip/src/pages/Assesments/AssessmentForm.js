import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { assessmentService } from '../../services/assessmentService';
import { contractService } from '../../services/contractService';

const AssessmentForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const contractIdFromQuery = searchParams.get('contract_id');
  
  const [formData, setFormData] = useState({
    contract_id: contractIdFromQuery || '',
    assessment_date: new Date().toISOString().split('T')[0],
    assessed_value: '',
    assessor_name: '',
    assessment_method: 'market_value',
    condition_rating: '5',
    notes: '',
    status: 'pending'
  });

  const [contracts, setContracts] = useState([]);
  const [selectedContract, setSelectedContract] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loadingContracts, setLoadingContracts] = useState(true);

  const isEditMode = !!id;

  useEffect(() => {
    fetchContracts();
    if (id) {
      fetchAssessment();
    }
  }, [id]);

  useEffect(() => {
    if (formData.contract_id) {
      const contract = contracts.find(c => c.contract_id === parseInt(formData.contract_id));
      setSelectedContract(contract);
    }
  }, [formData.contract_id, contracts]);

  const fetchContracts = async () => {
    try {
      setLoadingContracts(true);
      const data = await contractService.getAll();
      // Chỉ lấy hợp đồng còn hiệu lực
      const activeContracts = data.filter(c => c.status === 'active');
      setContracts(activeContracts);
    } catch (err) {
      console.error('Error fetching contracts:', err);
      setError('Lỗi khi tải danh sách hợp đồng');
    } finally {
      setLoadingContracts(false);
    }
  };

  const fetchAssessment = async () => {
    try {
      setLoading(true);
      const data = await assessmentService.getById(id);
      setFormData({
        contract_id: data.contract_id,
        assessment_date: data.assessment_date.split('T')[0],
        assessed_value: data.assessed_value,
        assessor_name: data.assessor_name || '',
        assessment_method: data.assessment_method || 'market_value',
        condition_rating: data.condition_rating || '5',
        notes: data.notes || '',
        status: data.status
      });
    } catch (err) {
      setError('Lỗi khi tải thông tin định giá');
      console.error('Error fetching assessment:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.contract_id) {
      setError('Vui lòng chọn hợp đồng');
      return;
    }
    if (!formData.assessed_value || parseFloat(formData.assessed_value) <= 0) {
      setError('Vui lòng nhập giá trị định giá hợp lệ');
      return;
    }
    if (!formData.assessor_name.trim()) {
      setError('Vui lòng nhập tên người định giá');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const dataToSubmit = {
        ...formData,
        assessed_value: parseFloat(formData.assessed_value),
        condition_rating: parseInt(formData.condition_rating)
      };

      if (isEditMode) {
        await assessmentService.update(id, dataToSubmit);
        alert('Cập nhật định giá thành công');
      } else {
        await assessmentService.create(dataToSubmit);
        alert('Tạo định giá mới thành công');
      }
      
      navigate('/assessments');
    } catch (err) {
      setError(err.message || 'Có lỗi xảy ra khi lưu định giá');
      console.error('Error saving assessment:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loadingContracts || (isEditMode && loading)) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">
          {isEditMode ? 'Chỉnh sửa định giá' : 'Tạo định giá mới'}
        </h1>
        <p className="text-gray-600 mt-2">
          {isEditMode ? 'Cập nhật thông tin định giá' : 'Nhập thông tin định giá phương tiện'}
        </p>
      </div>

      {error && (
        <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-600">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-6 space-y-6">
        {/* Contract Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Hợp đồng <span className="text-red-500">*</span>
          </label>
          <select
            name="contract_id"
            value={formData.contract_id}
            onChange={handleChange}
            disabled={isEditMode}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed"
          >
            <option value="">-- Chọn hợp đồng --</option>
            {contracts.map(contract => (
              <option key={contract.contract_id} value={contract.contract_id}>
                {contract.contract_number} - {contract.customer_name} - {contract.license_plate}
              </option>
            ))}
          </select>
          {selectedContract && (
            <div className="mt-2 p-3 bg-blue-50 rounded-lg text-sm">
              <p className="text-gray-700">
                <span className="font-medium">Khách hàng:</span> {selectedContract.customer_name}
              </p>
              <p className="text-gray-700">
                <span className="font-medium">Phương tiện:</span> {selectedContract.license_plate} - {selectedContract.vehicle_type}
              </p>
              <p className="text-gray-700">
                <span className="font-medium">Số tiền bảo hiểm:</span> {parseFloat(selectedContract.coverage_amount).toLocaleString('vi-VN')} VNĐ
              </p>
            </div>
          )}
        </div>

        {/* Assessment Date */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ngày định giá <span className="text-red-500">*</span>
          </label>
          <input
            type="date"
            name="assessment_date"
            value={formData.assessment_date}
            onChange={handleChange}
            max={new Date().toISOString().split('T')[0]}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Assessed Value */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Giá trị định giá (VNĐ) <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              name="assessed_value"
              value={formData.assessed_value}
              onChange={handleChange}
              min="0"
              step="100000"
              required
              placeholder="Ví dụ: 500000000"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            {formData.assessed_value && (
              <p className="mt-1 text-sm text-gray-600">
                {parseFloat(formData.assessed_value).toLocaleString('vi-VN')} VNĐ
              </p>
            )}
          </div>

          {/* Assessor Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Người định giá <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="assessor_name"
              value={formData.assessor_name}
              onChange={handleChange}
              required
              placeholder="Nhập tên người định giá"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Assessment Method */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phương pháp định giá
            </label>
            <select
              name="assessment_method"
              value={formData.assessment_method}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="market_value">Giá trị thị trường</option>
              <option value="replacement_cost">Chi phí thay thế</option>
              <option value="depreciated_value">Giá trị khấu hao</option>
              <option value="agreed_value">Giá trị thỏa thuận</option>
            </select>
          </div>

          {/* Condition Rating */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Đánh giá tình trạng (1-10)
            </label>
            <input
              type="number"
              name="condition_rating"
              value={formData.condition_rating}
              onChange={handleChange}
              min="1"
              max="10"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
            <div className="mt-2 flex justify-between text-xs text-gray-500">
              <span>1 (Rất kém)</span>
              <span>5 (Trung bình)</span>
              <span>10 (Xuất sắc)</span>
            </div>
          </div>
        </div>

        {/* Status */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Trạng thái
          </label>
          <select
            name="status"
            value={formData.status}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="pending">Chờ xử lý</option>
            <option value="approved">Đã duyệt</option>
            <option value="rejected">Từ chối</option>
          </select>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ghi chú
          </label>
          <textarea
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows="4"
            placeholder="Nhập các ghi chú về định giá, tình trạng phương tiện, lý do định giá..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-6 border-t">
          <button
            type="button"
            onClick={() => navigate('/assessments')}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Hủy
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {loading && (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            )}
            {isEditMode ? 'Cập nhật' : 'Tạo mới'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AssessmentForm;
