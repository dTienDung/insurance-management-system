import React, { useState, useEffect } from 'react';
import { dashboardAPI, exportAPI } from '../../services/api';
import Button from '../../components/common/Button';
import { downloadExcel } from '../../utils/fileDownload';

const ReportDashboard = () => {
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalContracts: 0,
    renewalRate: 0,
    avgContractValue: 0
  });

  const [revenueByMonth, setRevenueByMonth] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    fetchReports();
  }, [dateRange]);

  const fetchReports = async () => {
    try {
      setLoading(true);
      
      const [overview, revenue] = await Promise.all([
        dashboardAPI.getOverview(dateRange),
        dashboardAPI.getRevenueByMonth(dateRange)
      ]);

      setStats(overview.data.data || {});
      setRevenueByMonth(revenue.data.data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExportReport = async (type) => {
    try {
      const response = await exportAPI.exportReport(type, dateRange);
      downloadExcel(response.data, `BaoCao_${type}_${new Date().toISOString().split('T')[0]}`);
      alert('✅ Xuất báo cáo thành công!');
    } catch (error) {
      alert('❌ Không thể xuất báo cáo');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Báo cáo & Thống kê</h1>
        <p className="text-gray-600 mt-2">Tổng hợp số liệu kinh doanh</p>
      </div>

      {/* Date Range Filter */}
      <div className="mb-6 bg-white p-4 rounded-lg shadow flex items-center space-x-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Từ ngày</label>
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Đến ngày</label>
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
            className="px-3 py-2 border border-gray-300 rounded-lg"
          />
        </div>
        <div className="pt-6">
          <Button onClick={fetchReports}>Xem báo cáo</Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-lg shadow-lg">
          <div className="text-sm opacity-80">Tổng doanh thu</div>
          <div className="text-3xl font-bold mt-2">
            {new Intl.NumberFormat('vi-VN', { notation: 'compact' }).format(stats.totalRevenue)} đ
          </div>
          <div className="text-sm mt-2 opacity-80">+12% so với tháng trước</div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-lg shadow-lg">
          <div className="text-sm opacity-80">Hợp đồng mới</div>
          <div className="text-3xl font-bold mt-2">{stats.totalContracts}</div>
          <div className="text-sm mt-2 opacity-80">+5% so với tháng trước</div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 rounded-lg shadow-lg">
          <div className="text-sm opacity-80">Tỷ lệ tái tục</div>
          <div className="text-3xl font-bold mt-2">{stats.renewalRate}%</div>
          <div className="text-sm mt-2 opacity-80">+3% so với tháng trước</div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-6 rounded-lg shadow-lg">
          <div className="text-sm opacity-80">Giá trị TB/HĐ</div>
          <div className="text-3xl font-bold mt-2">
            {new Intl.NumberFormat('vi-VN', { notation: 'compact' }).format(stats.avgContractValue)} đ
          </div>
          <div className="text-sm mt-2 opacity-80">+8% so với tháng trước</div>
        </div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Doanh thu theo tháng</h2>
          <Button 
            variant="outline"
            size="sm"
            onClick={() => handleExportReport('revenue')}
          >
            📊 Xuất Excel
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Tháng</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Doanh thu</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Số HĐ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {revenueByMonth.map((item, index) => (
                <tr key={index} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm">{item.month}</td>
                  <td className="px-4 py-3 text-sm text-right font-medium">
                    {new Intl.NumberFormat('vi-VN').format(item.revenue)} đ
                  </td>
                  <td className="px-4 py-3 text-sm text-right">{item.contracts}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Export Actions */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Xuất báo cáo</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button 
            variant="outline"
            onClick={() => handleExportReport('revenue')}
          >
            📈 Báo cáo doanh thu
          </Button>
          <Button 
            variant="outline"
            onClick={() => handleExportReport('contracts')}
          >
            📄 Báo cáo hợp đồng
          </Button>
          <Button 
            variant="outline"
            onClick={() => handleExportReport('customers')}
          >
            👥 Báo cáo khách hàng
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ReportDashboard;
