import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Table from '../../components/common/Table';
import Button from '../../components/common/Button';
import customerService from '../../services/customerService';
import { format } from 'date-fns';
import { useTranslation } from '../../hooks/useTranslation';

const CustomerList = () => {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const { t } = useTranslation();

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const response = await customerService.getAll();
      setCustomers(response.data || []);
    } catch (error) {
      console.error('Error fetching customers:', error);
      alert('Không thể tải danh sách khách hàng');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      fetchCustomers();
      return;
    }

    try {
      setLoading(true);
      const response = await customerService.search(searchTerm);
      setCustomers(response.data || []);
    } catch (error) {
      console.error('Error searching:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (maKH) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa khách hàng này?')) {
      return;
    }

    try {
      await customerService.delete(maKH);
      alert('Xóa khách hàng thành công!');
      fetchCustomers();
    } catch (error) {
      console.error('Error deleting:', error);
      alert('Không thể xóa khách hàng');
    }
  };

  const columns = [
    { 
      key: 'MaKH', 
      label: 'Mã KH',
      render: (row) => (
        <span className="font-medium text-blue-600">{row.MaKH}</span>
      )
    },
    { key: 'HoTen', label: 'Họ và tên' },
    { key: 'CMND_CCCD', label: 'CMND/CCCD' },
    { 
      key: 'NgaySinh', 
      label: 'Ngày sinh',
      render: (row) => format(new Date(row.NgaySinh), 'dd/MM/yyyy')
    },
    { key: 'SDT', label: 'Số điện thoại' },
    { key: 'Email', label: 'Email' },
    {
      key: 'actions',
      label: 'Thao tác',
      render: (row) => (
        <div className="flex space-x-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/customers/${row.MaKH}`);
            }}
            className="text-blue-600 hover:text-blue-800"
          >
            Xem
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/customers/edit/${row.MaKH}`);
            }}
            className="text-green-600 hover:text-green-800"
          >
            Sửa
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleDelete(row.MaKH);
            }}
            className="text-red-600 hover:text-red-800"
          >
            Xóa
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Quản lý Khách hàng</h1>
        <p className="mt-2 text-gray-600">Danh sách tất cả khách hàng trong hệ thống</p>
      </div>

      {/* Search & Actions */}
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div className="flex space-x-2 w-full sm:w-auto">
          <input
            type="text"
            placeholder="Tìm kiếm theo tên, CMND, SĐT..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="flex-1 sm:w-80 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <Button variant="secondary" onClick={handleSearch}>
            Tìm kiếm
          </Button>
        </div>

        <Button 
          variant="primary"
          onClick={() => navigate('/customers/new')}
          icon={
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          }
        >
          Thêm khách hàng
        </Button>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Tổng khách hàng</div>
          <div className="text-2xl font-bold text-gray-900">{customers.length}</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Khách hàng mới (tháng này)</div>
          <div className="text-2xl font-bold text-blue-600">
            {customers.filter(c => {
              const created = new Date(c.NgayTao || Date.now());
              const now = new Date();
              return created.getMonth() === now.getMonth() && created.getFullYear() === now.getFullYear();
            }).length}
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-sm text-gray-500">Có hợp đồng hiệu lực</div>
          <div className="text-2xl font-bold text-green-600">-</div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow">
        <Table
          columns={columns}
          data={customers}
          loading={loading}
          onRowClick={(row) => navigate(`/customers/${row.MaKH}`)}
          emptyMessage="Chưa có khách hàng nào"
        />
      </div>
    </div>
  );
};

export default CustomerList;
