import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { customerAPI } from '../../services/api';
import Button from '../../components/common/Button';

const CustomerForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);

  const [formData, setFormData] = useState({
    HoTen: '',
    CMND_CCCD: '',
    NgaySinh: '',
    DiaChi: '',
    SDT: '',
    Email: ''
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEdit) {
      fetchCustomer();
    }
  }, [id]);

  const fetchCustomer = async () => {
    try {
      const response = await customerAPI.getById(id);
      const customer = response.data.data;
      setFormData({
        ...customer,
        NgaySinh: customer.NgaySinh?.split('T')[0] || ''
      });
    } catch (error) {
      alert('Không thể tải thông tin khách hàng');
      navigate('/customers');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.HoTen.trim()) newErrors.HoTen = 'Vui lòng nhập họ tên';
    if (!formData.CMND_CCCD.trim()) newErrors.CMND_CCCD = 'Vui lòng nhập CMND/CCCD';
    if (!formData.NgaySinh) newErrors.NgaySinh = 'Vui lòng chọn ngày sinh';
    if (!formData.SDT.trim()) newErrors.SDT = 'Vui lòng nhập số điện thoại';
    else if (!/^[0-9]{10}$/.test(formData.SDT)) {
      newErrors.SDT = 'Số điện thoại phải có 10 chữ số';
    }
    if (formData.Email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.Email)) {
      newErrors.Email = 'Email không hợp lệ';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validate()) return;

    try {
      setLoading(true);
      
      if (isEdit) {
        await customerAPI.update(id, formData);
        alert('✅ Cập nhật khách hàng thành công!');
      } else {
        await customerAPI.create(formData);
        alert('✅ Thêm khách hàng thành công!');
      }
      
      navigate('/customers');
    } catch (error) {
      alert('❌ ' + (error.response?.data?.message || 'Có lỗi xảy ra'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">
          {isEdit ? 'Cập nhật Khách hàng' : 'Thêm Khách hàng mới'}
        </h1>
        <p className="text-gray-600 mt-2">
          {isEdit ? 'Chỉnh sửa thông tin khách hàng' : 'Nhập thông tin khách hàng mới'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Họ tên */}
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Họ và tên <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="HoTen"
              value={formData.HoTen}
              onChange={handleChange}
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.HoTen ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.HoTen && <p className="text-red-500 text-sm mt-1">{errors.HoTen}</p>}
          </div>

          {/* CMND/CCCD */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              CMND/CCCD <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="CMND_CCCD"
              value={formData.CMND_CCCD}
              onChange={handleChange}
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.CMND_CCCD ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.CMND_CCCD && <p className="text-red-500 text-sm mt-1">{errors.CMND_CCCD}</p>}
          </div>

          {/* Ngày sinh */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ngày sinh <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              name="NgaySinh"
              value={formData.NgaySinh}
              onChange={handleChange}
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.NgaySinh ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.NgaySinh && <p className="text-red-500 text-sm mt-1">{errors.NgaySinh}</p>}
          </div>

          {/* Địa chỉ */}
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Địa chỉ
            </label>
            <textarea
              name="DiaChi"
              value={formData.DiaChi}
              onChange={handleChange}
              rows="3"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Số điện thoại */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Số điện thoại <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              name="SDT"
              value={formData.SDT}
              onChange={handleChange}
              placeholder="0912345678"
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.SDT ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.SDT && <p className="text-red-500 text-sm mt-1">{errors.SDT}</p>}
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email
            </label>
            <input
              type="email"
              name="Email"
              value={formData.Email}
              onChange={handleChange}
              placeholder="example@email.com"
              className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                errors.Email ? 'border-red-500' : 'border-gray-300'
              }`}
            />
            {errors.Email && <p className="text-red-500 text-sm mt-1">{errors.Email}</p>}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex justify-end space-x-3">
          <Button
            type="button"
            variant="ghost"
            onClick={() => navigate('/customers')}
          >
            Hủy
          </Button>
          <Button
            type="submit"
            variant="primary"
            loading={loading}
          >
            {isEdit ? 'Cập nhật' : 'Thêm mới'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CustomerForm;
